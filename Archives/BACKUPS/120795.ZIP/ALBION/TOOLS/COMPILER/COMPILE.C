/************
 * NAME     : COMPILE.C
 * AUTHOR   : Jurie Horneman, BlueByte
 * START    : 22-7-1994
 * PROJECT  : XLD Library compiler
 * NOTES    :
 * SEE ALSO : XLOAD.C
 ************/

/* includes */

#include <dos.h>
#include <stdio.h>
#include <fcntl.h>
#include	<sys\types.h>
#include	<sys\stat.h>
#include <io.h>

#include <BBDEF.H>
#include <BBBASMEM.H>
#include <BBMEM.H>

/* defines */

struct XLD_Library {
	UNCHAR ID[4];					/* Library ID ('XLD0') */
	UNCHAR Format;					/* 'I' for Intel, 'M' for Motorola */
	UNBYTE Library_type;			/* See above */
	UNSHORT Nr_subfiles;			/* Number of subfiles in this library */
};

/* XLD library types */
#define XLD_NORMAL				(0)
#define XLD_PACKED				(1)
#define XLD_ENCRYPTED			(2)
#define XLD_PACKED_ENCRYPTED	(3)

#define SUBFILES_MAX				(999)

#define PATH_LENGTH	(100)
#define INFO_LINES	(4)
#define BUFFER_SIZE	(1000000)

/* global variables */

int Library, Subfile;

BOOLEAN Packed, Encrypted;

UNLONG Lengths[SUBFILES_MAX + 1];
UNLONG Zero = 0;

UNSHORT Nr_subfiles, Max_subfiles, Highest_subfile;

UNCHAR *Subfiles[SUBFILES_MAX + 1];
UNCHAR Subfilenames[(SUBFILES_MAX + 1) * PATH_LENGTH];

UNCHAR Source_path[PATH_LENGTH],Library_path[PATH_LENGTH];
UNCHAR Source_fname[15];

UNCHAR XLD_ID[4] = {'X','L','D','0'};
UNCHAR Format = 'I';

UNBYTE Library_types[4] = {
	XLD_NORMAL,
	XLD_PACKED,
	XLD_ENCRYPTED,
	XLD_PACKED_ENCRYPTED
};

UNBYTE *Buffer;

UNBYTE *Output_address;
UNLONG Output_length, Total_unpacked;

UNSHORT Nr_index;

/* prototypes */

void BBMAIN(int argc, char **argv);
BOOLEAN Read_info_file(UNCHAR *Path);
void Get_subfile_data(UNCHAR *Path);
void Encrypt_block(UNSHORT seed, UNSHORT *ptr, UNLONG length);
void Load_subfile(UNSHORT i);

/* yo-ho */

void
BBMAIN(int argc, char **argv)
{
	UNSHORT Subfiles_in_current_sublib;
	UNSHORT First_subfile_nr;
	UNSHORT Desired_sublib_nr = 0xFFFF;
	UNSHORT Current_sublib_nr;
	UNSHORT i;

	/* Exit if number of parameters is wrong */
	if (argc < 2)
	{
		printf("\n");
		printf("Syntax : Compile {infofilename} [library number].\n");
		printf("Written by J.Horneman.\n");
		printf("          Start : 22-7-1994.\n");
		printf("Current version : 18-5-1995.\n");
		printf("\n");
		printf("This tool will compile an XLD-library using instructions from the\n");
		printf("infofile, which should have the following format :\n");
		printf("\n");
/*		printf("PACKED          (if you want the subfiles to be packed)\n");
		printf("ENCRYPTED       (if you want the subfiles to be encrypted)\n"); */
		printf("[Source_path]   (where the subfiles are, just the path!)\n");
		printf("[Source_file]   (which must contain the ???-wildcard)\n");
		printf("[Library_path]  (i.e. the full path of the target library)\n");
		printf("[Max_subfiles]  (optionally, the number of subfiles in the library)\n");
		printf("\n");
		return;
	}

	/* Try to read info-file */
	if (!Read_info_file(argv[1]))
		return;

	/* Read sub-library number (if any) */
	if (argc == 3)
		Desired_sublib_nr = atoi(argv[2]);

	/* Feedback */
	printf("\n");
	printf("************************************************************\n");
	printf("Compiling XLD-library.\n");
	printf("Source : %s%s.\n",Source_path,Source_fname);
	printf("Target : %s.\n",Library_path);
/*	if (Packed)
		printf("Packed / ");
	else
		printf("Unpacked / ");
	if (Encrypted)
		printf("encrypted.\n");
	else
		printf("not encrypted.\n"); */
	printf("************************************************************\n");
	printf("\n");

	/* Read paths and lengths of subfiles */
	Get_subfile_data(Source_path);
/*	if (!Nr_subfiles)
	{
		printf("No subfiles were found.");
		return;
	} */

	/* Implement maximum number of subfiles */
	if (Max_subfiles)
	{
		Highest_subfile = Max_subfiles;
		if (Nr_subfiles > Max_subfiles)
			Nr_subfiles = Max_subfiles;
	}

	/* Try to get work memory */
	Buffer = BASEMEM_Alloc(BUFFER_SIZE, BASEMEM_Status_Flat);
	if (!Buffer)
	{
		printf("Not enough memory!\n");
		return;
	}

	for (Current_sublib_nr = 0;Current_sublib_nr <= Highest_subfile / 100;
	 Current_sublib_nr++)
	{
		if (Desired_sublib_nr != 0xFFFF)
		{
			if (Current_sublib_nr != Desired_sublib_nr)
				continue;
		}

		{
			UNSHORT Length;
			UNCHAR *Number = "0";

			/* Select subfile group */
			Length = strlen(Library_path);
			sprintf(Number, "%u", Current_sublib_nr);
			*(Library_path + Length - 5) = *Number;
		}

		if (Current_sublib_nr)
		{
			First_subfile_nr = Current_sublib_nr * 100;

			if (Current_sublib_nr == Highest_subfile / 100)
			{
				Subfiles_in_current_sublib = Highest_subfile % 100 + 1;
			}
			else
			{
				Subfiles_in_current_sublib = 100;
			}
		}
		else
		{
			First_subfile_nr = 1;

			if (Current_sublib_nr == Highest_subfile / 100)
			{
				Subfiles_in_current_sublib = Highest_subfile;
			}
			else
			{
				Subfiles_in_current_sublib = 99;
			}
		}

		/* Try to open library */
		Library = open(Library_path,O_WRONLY|O_CREAT|O_BINARY, S_IRWXU | S_IRWXG | S_IRWXO);
		if (!Library)
		{
			printf("Library couldn't be opened.\n");
			return;
		}

		/* Write library header */
		write(Library,&XLD_ID[0],4);
		write(Library,&Format,1);

		if (Packed)
		{
			if (Encrypted)
				write(Library, &Library_types[XLD_PACKED], 1);
			else
				write(Library, &Library_types[XLD_PACKED_ENCRYPTED], 1);

			write(Library, &Subfiles_in_current_sublib, 2);

			/* Write dummy subfile lengths */
			for (i=0;i<Subfiles_in_current_sublib;i++)
				write(Library, &Zero, 4);
		}
		else
		{
			if (Encrypted)
				write(Library, &Library_types[XLD_ENCRYPTED], 1);
			else
				write(Library, &Library_types[XLD_NORMAL], 1);

			write(Library, &Subfiles_in_current_sublib, 2);

			/* Write subfile lengths */
			for (i=0;i<Subfiles_in_current_sublib;i++)
				write(Library, &Lengths[First_subfile_nr + i], 4);
		}

		/* Compile library */
		Total_unpacked = 0;
		for (i=0;i<Subfiles_in_current_sublib;i++)
		{
			if (Subfiles[First_subfile_nr + i])
			{
				/* Load subfile */
				Load_subfile(First_subfile_nr + i);

				if (!Packed)
				{
					if (Encrypted)
					{
						Encrypt_block(First_subfile_nr + i + 1, (UNSHORT *) Buffer,
						 Lengths[First_subfile_nr + i]);
					}

					Output_address = Buffer;
					Output_length = Lengths[First_subfile_nr + i];
					Total_unpacked += Lengths[First_subfile_nr + i];
				}

				/* Write subfile to Omnifile */
				write(Library,Output_address,Output_length);
			}
		}

		/* Write subfile lengths (if packing) */
		if (Packed)
		{
			lseek(Library,sizeof(struct XLD_Library),SEEK_SET);

			/* Write subfile lengths */
			for (i=0;i<Subfiles_in_current_sublib;i++)
				write(Library,&Lengths[First_subfile_nr + i],4);
		}

		/* Close library */
		close(Library);

		/* Status report */
		printf("XLD-library %u contains ", Current_sublib_nr);

		if (Subfiles_in_current_sublib == 1)
			printf("1 file.\n");
		else
			printf("%u files.\n", Subfiles_in_current_sublib);

		printf("Library length : %u.\n",Total_unpacked +
		 (Subfiles_in_current_sublib * 4) + sizeof(struct XLD_Library));
	}
}

/************************************************************************
 * Read and interpret info-file
 ************************************************************************/
BOOLEAN
Read_info_file(UNCHAR *Path)
{
	FILE *File;
	UNCHAR Info[INFO_LINES][200], *p;
	UNSHORT i = 0;

	/* Open info-file */
	File = fopen(Path,"r");
	if (!File)
	{
		printf("Info-file %s couldn't be opened.\n",Path);
		return(FALSE);
	}

	/* Yes -> Read strings */
	while (fgets(Info[i],200,File))
	{
		/* Until EOF or INFO_LINES strings have been read */
		i++;
		if (i==INFO_LINES)
			break;
	}
	/* Close file */
	fclose(File);

	/* Exit if less than INFO_LINES strings were read */
	if (i!=INFO_LINES)
	{
		printf("Illegal info-file %s.\n",Path);
		return(FALSE);
	}

	/* Check packed flag */
//	if (strncmp(Info[0],"PACKED",6)==0) Packed = TRUE;

	/* Check encrypted flag */
//	if (strncmp(Info[1],"ENCRYPTED",9)==0) Encrypted = TRUE;

	/* Get paths and filename */
	strcpy(Source_path,Info[0]);
	strcpy(Source_fname,Info[1]);
	strcpy(Library_path,Info[2]);

	/* Remove EOLs */
	Source_path[strlen(Source_path)-1] = 0;
	Source_fname[strlen(Source_fname)-1] = 0;
	Library_path[strlen(Library_path)-1] = 0;

	/* Find number index */
	p = (UNCHAR *) strstr(Source_fname,"???");
	if (!p)
		{
		printf("Source-filename does not contain ???.\n");
		return(FALSE);
		}
	Nr_index = p-Source_fname;

	/* Get maximum number of subfiles */
	if (Info[3]!="")
		Max_subfiles = atoi(Info[5]);

	return(TRUE);
}

/************************************************************************
 * Get paths and lengths of all subfiles
 ************************************************************************/
void
Get_subfile_data(UNCHAR *Source_path)
{
	struct find_t Fileinfo;
	unsigned rc;
	UNCHAR *Fname, *Ptr, Nr[4];
	UNCHAR Path[PATH_LENGTH];
	UNSHORT i,l;

	/* Build complete path */
	strcpy(Path,Source_path);
	strcat(Path,Source_fname);

	/* Clear arrays */
	for (i=0;i<SUBFILES_MAX;i++)
	{
		Subfiles[i]=NULL;
		Lengths[i]=0;
	}

	/* Reset variables */
	Nr_subfiles = 0;
	Highest_subfile = 0;
	Ptr = Subfilenames;

	/* Find all files */
	rc = _dos_findfirst(Path,_A_NORMAL,&Fileinfo);
	while (!rc)
	{
		/* Get path of current file */
		Fname = (UNCHAR *) Fileinfo.name;

		/* Extract subfile number from path */
		Nr[0]=Fname[Nr_index];
		Nr[1]=Fname[Nr_index+1];
		Nr[2]=Fname[Nr_index+2];
		Nr[3]=0;
		i = atoi(Nr);

		/* Is zero ? */
		if (i)
		{
			/* No -> Too large ? */
			if (i>SUBFILES_MAX)
			{
				/* Yes -> Tell off */
				printf("Subfile number %d too large!\n",i);
			}
			else
			{
				/* No -> Increase maximum subfile number if necessary */
				if (i>Highest_subfile)
					Highest_subfile = i;

				/* Store length and path of subfile */
				Lengths[i] = Fileinfo.size;
				Subfiles[i] = Ptr;

//				printf(">>>file %u : %s, %u bytes.\n",i,Fname,Lengths[i]);

				/* Copy path */
				strcpy(Ptr,Source_path);
				Ptr += strlen(Source_path);
				strcpy(Ptr,Fname);
				Ptr += strlen(Fname)+1;

				/* Increase total number of subfiles */
				Nr_subfiles++;
			}
		}
		/* Find next file */
		rc = _dos_findnext(&Fileinfo);
	}
}

/************************************************************************
 * Encrypt block
 ************************************************************************/
void
Encrypt_block(UNSHORT seed, UNSHORT *ptr, UNLONG length)
{
	UNSHORT v;
	UNLONG j;

	for (j=0;j<=length/2;j++)
	{
		v = *ptr;
		v = v^seed;
		*(ptr++) = v;
		seed = seed*17+87;
	}
}

/************************************************************************
 * Load subfile
 ************************************************************************/
void
Load_subfile(UNSHORT i)
{
	int fh;
	UNLONG Length;

	fh = open(Subfiles[i],O_RDONLY|O_BINARY);
	Length = filelength(fh);
	read(fh,Buffer,Length);
	close(fh);
}

