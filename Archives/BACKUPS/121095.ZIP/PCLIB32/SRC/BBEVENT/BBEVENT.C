#include <bbdef.h>
#include <bbdsa.h>
#include <bbevent.h>
#include <bbsystem.h>
#include <bbbasmem.h>

#include <string.h>

#include "include\blvintrn.h"
#include "..\..\lib\asminc\BB_INL_A.H"

#ifdef BBBLEV_ERRORHANDLING
	#include <BBERROR.h>
	#include <stdio.h>
#endif

/* Die folgende Konstante definiert die Gr��e des Eventbuffers */
#define BLEV_MAXEVENTS	32

/* BLEV Library status */
BOOLEAN BLEV_Library_Status = FALSE;

/* Das folgende Array enth�lt den Ringbuffer */
BLEV_Event_struct a_events[ BLEV_MAXEVENTS];

/* Die folgenden Variablen legen Anfang und Ende des belegten Bereiches im Ringbuffer fest. */

/* Enth�lt den Index des Elementes im Ringbuffer, das als n�chstes ausgelesen werden mu�, oder
    anders gesagt, den Event, der als n�chstes zur�ckgeliefert wird */
SILONG	sl_next_get_event;

/* Enth�lt den Index des Elementes im Ringbuffer, an das als n�chstes ein Eintrag geschrieben
   wird. */
SILONG	sl_next_put_event;

/* Error handling */
#ifdef BBBLEV_ERRORHANDLING

	/* Name of Library */
	char BBBLEV_LibraryName[] = "BBEVENT Library";

#endif


/* Dieses Flag gibt Auskunft �ber den Status des Ringbuffers. */
enum { BLEV_BUFFER_EMPTY, BLEV_EVENT_IN_BUFFER, BLEV_BUFFER_FULL } en_bufferstatus;

/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_Init
 * FUNCTION : 
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:16:56
 * LAST     : 13.06.95 00:16:56
 * INPUTS   :  void  : 
 * RESULT   : SILONG : 
 * BUGS     : 
 * NOTES    :	Achtung !!! Wenn BLEV_Init aufgerufen wurde sollte davor auf jeden
 *							Fall auch DSA_Init und SYSTEM_Init aufgerufen worden sein
 *						wird ansonsten auch automatisch erledigt
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

SILONG BLEV_Init( void )
{
	/* DSALibrary wird ben�tigt welche BASEMEM initialisiert */
	if(!DSA_Init()){
		#ifdef BBBLEV_ERRORHANDLING
		{
			/* Local vars */
			struct BBBLEV_ErrorStruct error;

			/* Fill out error structure */
			error.errorname	= "BLEV_Init: Cannot Init DSA";
			error.errordata	= 0;

			/* Push error on stack */
			ERROR_PushError( BLEV_PrintError, ( UNCHAR * ) &BBBLEV_LibraryName[0], sizeof( struct BBBLEV_ErrorStruct ), ( UNBYTE * ) &error );
		}
		#endif
		return(FALSE);
	}

	/* Library already initialised ? */
	if( BLEV_Library_Status ){
		/* Yes: nothing to do */
		return(TRUE);
	}

	/* Der Buffer wird als leer gekennzeichnet und die beiden Indexvariablen entsprechend gesetzt */
	en_bufferstatus	= BLEV_BUFFER_EMPTY;
	sl_next_get_event = 0;
	sl_next_put_event = 0;

	BLEV_Library_Status=TRUE;

	return( TRUE );
}

/* #FUNCTION END# */



/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_Exit
 * FUNCTION :
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:16:28
 * LAST     : 13.06.95 00:16:28
 * INPUTS   :  void  : 
 * RESULT   : None.
 * BUGS     : 
 * NOTES    : 
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

void BLEV_Exit( void )
{
	/* Library already initialised ? */
	if( !BLEV_Library_Status ){
		/* Yes: nothing to do */
		return;
	}

	/* Hier ist momentan nix zu tun.. */
	BLEV_Library_Status=FALSE;

}

/* #FUNCTION END# */

/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_IsEventWaiting
 * FUNCTION : Warten bis Event auftritt
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:15:59
 * LAST     : 13.06.95 00:15:59
 * INPUTS   :  void  : 
 * RESULT   : SILONG : 
 * BUGS     : 
 * NOTES    : 
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

SILONG BLEV_IsEventWaiting( void )
{
	return( en_bufferstatus != BLEV_BUFFER_EMPTY );
}

/* #FUNCTION END# */

/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_ClearAllEvents
 * FUNCTION : Event Stack entleeren
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:14:25
 * LAST     : 13.06.95 00:14:25
 * INPUTS   :  
 * RESULT   : None.
 * BUGS     : 
 * NOTES    : 
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

void BLEV_ClearAllEvents( void )
{
	/* Der Buffer wird als leer gekennzeichnet und die beiden Indexvariablen entsprechend gesetzt */
	en_bufferstatus	= BLEV_BUFFER_EMPTY;
	sl_next_get_event = 0;
	sl_next_put_event = 0;
}

/* #FUNCTION END# */

/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_PutEvent
 * FUNCTION : Event auf Eventstack kopieren
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:13:15
 * LAST     : 13.06.95 00:13:15
 * INPUTS   :  struct BLEV_Event_struct		*p_event  : Zeiger auf zu erzeugenden Event
 * RESULT   : SILONG : TRUE = Event konnte erzeugt werden
 *										 FALSE = Event Buffer voll
 * BUGS     : 
 * NOTES    : 
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

#pragma off (check_stack)

SILONG BLEV_PutEvent( struct BLEV_Event_struct		*p_event )
{

	/* Wenn der Buffer voll ist, gibt's einen Fehler */
	if(  en_bufferstatus == BLEV_BUFFER_FULL )
	{
		return( FALSE );
	};

	/* Der Event wird in den Buffer kopiert */
//	memcpy( &a_events[ sl_next_put_event ], p_event, sizeof( BLEV_Event_struct ));
	intmemcopy( (UNBYTE *)p_event, (UNBYTE *)&a_events[ sl_next_put_event ], sizeof( BLEV_Event_struct ) );

	/* Anpassen des Endezeigers. Dabei eventuell den Wraparound ber�cksichtigen */
	if( (++sl_next_put_event) == BLEV_MAXEVENTS )
		/* Wraparound */
		sl_next_put_event = 0;

	/* Testen, ob durch das Einf�gen der Buffer voll wurde */
	if( sl_next_put_event == sl_next_get_event )
		en_bufferstatus = BLEV_BUFFER_FULL;
	else
		en_bufferstatus = BLEV_EVENT_IN_BUFFER;

	return( TRUE );

}

#pragma on (check_stack)

/* #FUNCTION END# */




/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME     : BLEV_GetEvent
 * FUNCTION : Event vom EventStack holen
 * FILE     : D:\PCLIB32\SRC\BBEVENT\BBEVENT.C
 * AUTHOR   : Rainer Reber
 * FIRST    : 13.06.95 00:11:40
 * LAST     : 13.06.95 00:11:40
 * INPUTS   :  struct BLEV_Event_struct	*p_event  : Zeiger auf Event-Struktur
 * RESULT   : SILONG : TRUE = Event wurde �bergeben
 *										 FALSE = keine Event mehr im Buffer
 * BUGS     : 
 * NOTES    : 
 * VERSION  : 1.0 
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

SILONG BLEV_GetEvent( struct BLEV_Event_struct	*p_event )
{
	/* Testen, ob der Buffer leer ist, oder ob er ein g�ltiges Element enth�lt */
	if(  en_bufferstatus == BLEV_BUFFER_EMPTY )
	{
		/* wenn kein Event erzeugt Mausposition trotzdem zur�ckgeben */
		p_event->sl_eventtype 	= BLEV_NOEVENT;
		p_event->p_screenport 	= SYSTEM_ActiveScreenPort;
		p_event->ul_pressed_keys	= SYSTEM_GetBLEVStatusLong();
		p_event->sl_key_code		= 0;
		p_event->sl_mouse_x		= SYSTEMVAR_mousex;
		p_event->sl_mouse_y		= SYSTEMVAR_mousey;

		return( FALSE );
	};

	/* Kopieren des Events in den Parameter */
//	memcpy( p_event, &a_events[ sl_next_get_event ], sizeof( BLEV_Event_struct ));
	intmemcopy( (UNBYTE *)&a_events[ sl_next_get_event ],(UNBYTE *)p_event, sizeof( BLEV_Event_struct ));

	/* Der Zeiger auf das n�chste zu lesende Element wird weitergeschaltet */
	/* Anpassen des Endezeigers. Dabei eventuell den Wraparound ber�cksichtigen */
	if( (++sl_next_get_event) == BLEV_MAXEVENTS )
		/* Wraparound */
		sl_next_get_event = 0;

	/* Testen, ob durch das Entnehmen der Buffer leer wurde */
	if( sl_next_get_event == sl_next_put_event )
		en_bufferstatus = BLEV_BUFFER_EMPTY;
	else
		en_bufferstatus = BLEV_EVENT_IN_BUFFER;

	return( TRUE );

}
/* #FUNCTION END# */



/*
******************************************************************************
* #FUNCTION HEADER BEGIN#
* NAME      : BLEV_GetMouseX
* FUNCTION  : Mausposition X auslesen
* INPUTS    :
* RESULT    :
* FILE      :
* AUTHOR    :
* FIRST     :
* LAST      :
* BUGS      :
* NOTES     :
* SEE ALSO  :
* VERSION   : 0.1
* #FUNCTION HEADER END#
*/

/* #FUNCTION BEGIN# */
void BLEV_GetMousePos(struct BBPOINT *pnt)
{
	pnt->x=SYSTEMVAR_mousex;
	pnt->y=SYSTEMVAR_mousey;
}

/*
 ******************************************************************************
 * #FUNCTION HEADER BEGIN#
 * NAME      : BLEV_PrintError
 * FUNCTION  : Print error function for BLEV library
 * INPUTS    : UNCHAR * buffer	:Pointer to string buffer.
 *             UNBYTE * data	:Pointer to error stack data area.
 * RESULT    : None.
 * #FUNCTION HEADER END#
 */

/* #FUNCTION BEGIN# */

#ifdef BBBLEV_ERRORHANDLING

	void
	BLEV_PrintError( UNCHAR * buffer, UNBYTE * data )
	{
		/* Local vars */
		struct BBBLEV_ErrorStruct * BLEVErrorStructPtr=( struct BBBLEV_ErrorStruct * ) data;

		/* sprintf error message into string buffer */
		sprintf( ( char * ) buffer, "ERROR! %s %ld ", ( char * ) BLEVErrorStructPtr->errorname, BLEVErrorStructPtr->errordata );
	}

#endif

/* #FUNCTION END# */

